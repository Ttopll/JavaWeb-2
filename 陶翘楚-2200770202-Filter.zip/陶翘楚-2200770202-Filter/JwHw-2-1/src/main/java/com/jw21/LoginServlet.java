package com.jw21;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "LoginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 从请求中获取用户提交的登录信息
        String user = request.getParameter("user");
        String password = request.getParameter("password");

        // 打印获取到的用户信息
        System.out.println("Received login attempt for user: " + user);

        // 验证用户输入的用户名和密码是否正确
        if ("gsy".equals(user) && "123".equals(password)) {
            // 验证成功，将用户信息存储到会话中
            HttpSession session = request.getSession();
            session.setAttribute("User", user);
            session.setAttribute("Password", password);

            // 重定向到用户主页
            response.sendRedirect("hello-servlet"); // 假设有一个home.jsp页面作为用户主页
            System.out.println("Right_user:"+user);
            System.out.println("Right_password:"+password);
            System.out.println("User: " + user + ", Password: " + password + " . Welcome!");

        } else {
            // 验证失败，重定向到登录页面，并可能显示错误消息
            response.sendRedirect("/login-demo"); //
        }
    }
}
