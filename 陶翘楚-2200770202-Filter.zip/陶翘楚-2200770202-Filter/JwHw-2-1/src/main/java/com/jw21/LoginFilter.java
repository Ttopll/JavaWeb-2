package com.jw21;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@WebFilter(filterName = "LoginFilter", urlPatterns = "/*")
public class LoginFilter implements Filter {

    private List<String> excludePaths = Arrays.asList("/login", "/register", "/public");

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // 从初始化参数中读取排除列表，如果有的话
        String excludePathsParam = filterConfig.getInitParameter("excludePaths");
        if (excludePathsParam != null && !excludePathsParam.isEmpty()) {
            excludePaths = Arrays.asList(excludePathsParam.split(","));
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        String requestURI = httpRequest.getRequestURI();

        // 检查请求路径是否在排除列表中
        if (isExcluded(requestURI)) {
            chain.doFilter(request, response);
            return;
        }

        // 检查用户是否已登录
        HttpSession session = httpRequest.getSession(false);
        if (session != null && session.getAttribute("user") != null) {
            chain.doFilter(request, response);
        } else {
            // 用户未登录，重定向到登录页面
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
        }
    }

    @Override
    public void destroy() {
        // 销毁过滤器时执行的操作（如果有）
    }

    private boolean isExcluded(String requestURI) {
        // 检查当前请求路径是否在排除列表中
        for (String path : excludePaths) {
            if (requestURI.startsWith(path)) {
                return true;
            }
        }
        return false;
    }
}