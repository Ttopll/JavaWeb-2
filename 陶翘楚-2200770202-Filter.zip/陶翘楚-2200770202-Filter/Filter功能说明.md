# LoginFilter 和 LoginServlet 实现文档

## LoginFilter

LoginFilter是一个实现了javax.servlet.Filter接口的类，用于拦截进入应用程序的所有HTTP请求，并根据用户的登录状态允许或重定向这些请求。

#### 功能

1. 请求拦截：过滤器检查每个请求的URI，以确定它是否属于不需要登录就可以访问的路径。
2. 排除列表：定义了一个排除列表，包含不需要登录就可以访问的路径，如/login、/register和/public。
3. 登录检查：如果请求的路径不在排除列表中，过滤器会检查用户是否已经登录，即检查session中是否存在"user"属性。
4. 重定向：如果用户未登录，请求会被重定向到登录页面/login。

#### 实现细节

- 使用@WebFilter注解配置过滤器，使其应用于所有URL路径"/*"。
- doFilter方法中实现了主要的逻辑流程。
- isExcluded方法用于检查当前请求路径是否在排除列表中。

#### 配置

LoginFilter可以通过web.xml或注解进行配置。在本实现中，使用了注解方式，并在init方法中允许从web.xml中读取排除路径参数。

***

## LoginServlet

LoginServlet是一个处理用户登录请求的HttpServlet。

#### 功能

1. 登录处理：接收用户提交的登录表单数据，并验证用户名和密码。
2. 会话管理：如果登录成功，将用户信息存储在session中，并重定向到主页。
3. 错误处理：如果登录失败，重定向回登录页面，并显示错误消息。

#### 实现细节

- doPost方法处理POST请求，执行登录验证。
- doGet方法处理GET请求，通常重定向到登录表单页面。

#### 配置

LoginServlet使用@WebServlet注解配置，指定URL模式为/login。

***

### 额外功能

- 会话超时：在LoginFilter中，可以通过设置session的最大非活动时间来实现会话超时功能。
- 动态排除列表：排除列表可以通过web.xml配置，使得在不重新编译代码的情况下，动态调整哪些路径不需要登录。

### 使用说明

1. 确保login-demo和home.jsp（假设有一个home.jsp页面作为用户主页）页面存在于正确的路径下。
2. 确保LoginFilter和LoginServlet已经正确配置在web.xml中，或者使用注解方式进行了配置。
3. 启动Servlet容器（如Tomcat），并通过浏览器访问应用程序。

### 注意事项

出于安全考虑，实际生产环境中不应明文存储密码。应使用加密存储和验证机制。

过滤器和Servlet的执行顺序可能受到Servlet容器配置的影响，确保LoginFilter在LoginServlet之前执行。

如果有多个过滤器，它们的执行顺序由web.xml中的配置顺序决定。