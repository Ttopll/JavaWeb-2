use employee_management;

# 1.查询所有员工的姓名、邮箱和工作岗位。
SELECT CONCAT(first_name,' ',last_name) AS '姓名' , email AS '邮箱' , job_title AS '工作岗位'
FROM employees;


# 2.查询所有部门的名称和位置。
SELECT d.dept_name AS 部门名称, d.location AS 位置
FROM departments AS d;


# 3.查询工资超过70000的员工姓名和工资。
SELECT *
FROM employees e
WHERE e.salary > 7000;


# 4.查询IT部门的所有员工。
SELECT e.* , d.dept_name
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
WHERE d.dept_name = 'IT';


# 5.查询入职日期在2020年之后的员工信息。
# SELECT *
# FROM employees e
# WHERE hire_date >= '2020-01-01';
SELECT *
FROM employees
WHERE YEAR(hire_date) > 2019;


# 6.计算每个部门的平均工资。
SELECT e.dept_id, d.dept_id ,AVG(e.salary) AS '平均工资'
FROM employees e
JOIN departments d on e.dept_id = d.dept_id
GROUP BY e.dept_id,d.dept_name
ORDER BY '平均工资';


# 7.查询工资最高的前3名员工信息。
SELECT *
FROM employees e
ORDER BY salary DESC
LIMIT 3;


# 8.查询每个部门员工数量。
SELECT e.dept_id, d.dept_name, COUNT(*) AS number_of_employees
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id
GROUP BY dept_id;


# 9.查询没有分配部门的员工。
SELECT *
FROM employees
WHERE dept_id IS NULL;


# 10.查询参与项目数量最多的员工。
SELECT e.*
FROM employees e
INNER JOIN (
    SELECT emp_id, COUNT(*) AS project_count
    FROM employee_projects
    GROUP BY emp_id
) AS ep ON e.emp_id = ep.emp_id
WHERE ep.project_count = (
    SELECT MAX(project_count)
    FROM (
        SELECT COUNT(*) AS project_count
        FROM employee_projects
        GROUP BY emp_id
    ) AS subquery
);


# 11.计算所有员工的工资总和。
SELECT sum(employees.salary) AS '工资总和'
FROM employees;


# 12.查询姓"Smith"的员工信息。
SELECT *
FROM employees
WHERE last_name = 'Smith';


# 13.查询即将在半年内到期的项目。
SELECT *
FROM projects
WHERE end_date >= CURDATE() AND end_date < DATE_ADD(CURDATE(), INTERVAL 6 MONTH);


# 14.查询至少参与了两个项目的员工。
SELECT e.*
FROM employees e
INNER JOIN (
    SELECT emp_id
    FROM employee_projects
    GROUP BY emp_id
    HAVING COUNT(*) >= 2
) ep ON e.emp_id = ep.emp_id;


# 15.查询没有参与任何项目的员工。
SELECT e.*
FROM employees e
LEFT JOIN employee_projects ep ON e.emp_id = ep.emp_id
WHERE ep.emp_id IS NULL;


# 16.计算每个项目参与的员工数量。
SELECT p.project_name, ep.employee_count AS '员工数量'
FROM projects p
LEFT JOIN (
    SELECT project_id, COUNT(*) AS employee_count
    FROM employee_projects
    GROUP BY project_id
) ep ON p.project_id = ep.project_id;


# 17.查询工资第二高的员工信息。
WITH salary_top AS (
    SELECT DISTINCT salary
    FROM employees e
    ORDER BY e.salary DESC
    LIMIT 1,1
)
SELECT *
FROM employees e
WHERE e.salary IN (
    SELECT *
    FROM salary_top
    );


# 18.查询每个部门工资最高的员工。
# SELECT e.*
# FROM employees e
# INNER JOIN (
#     SELECT dept_id, MAX(salary) AS max_salary
#     FROM employees
#     GROUP BY dept_id
# ) AS dept_max ON e.dept_id = dept_max.dept_id AND e.salary = dept_max.max_salary;
WITH tb_max_salary AS (
    SELECT e.dept AS dept_id , MAX(e.salary) AS max_salary
    FROM employees e
    GROUP BY e.dept_id
)
SELECT e.*
FROM employees e
Join tb_max_salary tms ON e.dept_id = tms.dept_id
WHERE e.salary = tms.max_salary;


# 19.计算每个部门的工资总和,并按照工资总和降序排列。
SELECT d.dept_name, dept_sum.sum_salary
FROM departments d
INNER JOIN (
    SELECT dept_id, sum(e.salary) AS sum_salary
    FROM employees e
    GROUP BY e.dept_id
) AS dept_sum ON d.dept_id = dept_sum.dept_id
ORDER BY dept_sum.sum_salary DESC;


# 20.查询员工姓名、部门名称和工资。
SELECT CONCAT(first_name,' ',last_name) AS '姓名' ,d.dept_name AS '部门名称' , e.salary AS '工资'
FROM employees e
JOIN departments d ON e.dept_id = d.dept_id;


# 23.查询平均工资最高的部门。
SELECT d.dept_id, dept_name, emp_dept_avg.emp_avrange
FROM departments d
INNER JOIN (
    SELECT dept_id ,AVG(salary) AS emp_avrange
    FROM employees e1
    group by dept_id
    ORDER BY emp_avrange DESC
    LIMIT 1
) AS emp_dept_avg ON d.dept_id = emp_dept_avg.dept_id;


# 24.查询工资高于其所在部门平均工资的员工。
SELECT *
FROM employees e1
WHERE e1.salary > (
    SELECT AVG(e2.salary)
    FROM employees e2
    WHERE e2.dept_id = e1.dept_id
    );


# 32.查询员工数量最多的部门。
SELECT *
FROM (
    SELECT dept_id, COUNT(*) AS num_employees
    FROM employees
    GROUP BY dept_id
) AS dept_counts
WHERE num_employees = (
    SELECT MAX(num_employees)
    FROM (
        SELECT COUNT(*) AS num_employees
        FROM employees
        GROUP BY dept_id
    ) AS subquery
);


# 33.查询参与项目最多的部门。
SELECT
    d.dept_id,
    d.dept_name,
    COUNT(DISTINCT ep.project_id) AS project_count
FROM departments d
JOIN employees e ON d.dept_id = e.dept_id
JOIN employee_projects ep ON e.emp_id = ep.emp_id
GROUP BY d.dept_id, d.dept_name
ORDER BY project_count DESC
LIMIT 1;


# 37.查询每个部门薪资最低的员工。
SELECT *
FROM employees
WHERE salary IN (
    SELECT MIN(salary)
    FROM employees
    GROUP BY dept_id
    );








use school;
# 1. 查询所有学生的信息。
SELECT *
FROM student;


# 2. 查询所有课程的信息。
SELECT *
FROM course;


# 3. 查询所有学生的姓名、学号和班级。
SELECT name, student_id, my_class
FROM student;


# 4. 查询所有教师的姓名和职称。
SELECT name, title
FROM teacher;


# 5. 查询不同课程的平均分数。
SELECT c.course_name, s.course_id, avg(score)
FROM score s
JOIN course c ON C.course_id = s.course_id
GROUP BY course_id;


# 6. 查询每个学生的平均分数。
SELECT s.student_id, s.name, avg(score)
FROM score sc
JOIN student s ON sc.student_id = s.student_id
GROUP BY s.student_id;


# 7.查询分数大于85分的学生学号和课程号。
SELECT student_id, course_id
FROM score sc
WHERE SC.score > 85;


# 8. 查询每门课程的选课人数。
SELECT course_id, COUNT(student_id)
FROM score sc
group by course_id;


# 9. 查询选修了"高等数学"课程的学生姓名和分数。
SELECT sc.student_id, sc.score
FROM score sc
JOIN course c ON sc.course_id = c.course_id
WHERE course_name = '高等数学';


# 10. 查询没有选修"大学物理"课程的学生姓名。
SELECT s.name
FROM student s
WHERE s.student_id NOT IN (
    SELECT sc.student_id
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    WHERE c.course_name = '大学物理'
);


# 11. 查询C001比C002课程成绩高的学生信息及课程分数。
SELECT s1.student_id, s1.name, sc1.course_id AS course_id_1, sc2.course_id AS course_id_2, sc1.score AS score_1, sc2.score AS score_2
FROM score sc1
JOIN score sc2 ON sc1.student_id = sc2.student_id
JOIN student s1 ON sc1.student_id = s1.student_id
WHERE sc1.course_id = 'C001' AND sc2.course_id = 'C002'
AND sc1.score > sc2.score;


# 12. 统计各科成绩各分数段人数：课程编号，课程名称，[100-85]，[85-70]，[70-60]，[60-0] 及所占百分比
SELECT
    c.course_id,
    c.course_name,
    SUM(IF(sc.score >= 100 OR sc.score < 85, 1, 0))                                          AS `100-85`,
    SUM(IF(sc.score >= 85 AND sc.score < 70, 1, 0))                                          AS `85-70`,
    SUM(IF(sc.score >= 70 AND sc.score < 60, 1, 0))                                          AS `70-60`,
    SUM(IF(sc.score >= 60, 1, 0))                                                            AS `60-0`,
    ROUND((SUM(IF(sc.score >= 100 OR sc.score < 85, 1, 0)) / COUNT(sc.student_id)) * 100, 2) AS `100-85_PCT`,
    ROUND((SUM(IF(sc.score >= 85 AND sc.score < 70, 1, 0)) / COUNT(sc.student_id)) * 100, 2) AS `85-70_PCT`,
    ROUND((SUM(IF(sc.score >= 70 AND sc.score < 60, 1, 0)) / COUNT(sc.student_id)) * 100, 2) AS `70-60_PCT`,
    ROUND((SUM(IF(sc.score >= 60, 1, 0)) / COUNT(sc.student_id)) * 100, 2)                   AS `60-0_PCT`
FROM score sc
JOIN course c ON sc.course_id = c.course_id
GROUP BY c.course_id, c.course_name;


# 13.查询选择C002课程但没选择C004课程的成绩情况(不存在时显示为 null )。
SELECT
    sc1.student_id,
    sc1.score AS c002_score,
    sc2.score AS c004_score
FROM score sc1
LEFT JOIN score sc2 ON sc1.student_id = sc2.student_id AND sc2.course_id = 'C004'
WHERE sc1.course_id = 'C002'
      AND sc1.student_id NOT IN (
        SELECT student_id
        FROM score
        WHERE course_id = 'C004'
    );


# 14.查询平均分数最高的学生姓名和平均分数。
SELECT name, MAX(avg_sorce)
FROM student s
INNER JOIN (
    SELECT sc.student_id,AVG(score) AS avg_sorce
    FROM score sc
    GROUP BY student_id
) AS sc_avg ON s.student_id = sc_avg.student_id
GROUP BY name;


# 15. 查询总分最高的前三名学生的姓名和总分。
SELECT name, three.sum_three
FROM student s
INNER JOIN (
    SELECT sc.student_id, sum(score) AS sum_three
    FROM score sc
    GROUP BY student_id
) AS three ON s.student_id = three.student_id
ORDER BY three.sum_three DESC
LIMIT 3;


# 16. 查询各科成绩最高分、最低分和平均分。要求如下：
# 以如下形式显示：课程 ID，课程 name，最高分，最低分，平均分，及格率，中等率，优良率，优秀率
# 及格为>=60，中等为：70-80，优良为：80-90，优秀为：>=90
# 要求输出课程号和选修人数，查询结果按人数降序排列，若人数相同，按课程号升序排列
SELECT
    c.course_id                                                                     AS '课程ID',
    c.course_name                                                                   AS '课程 name',
    MAX(sc.score)                                                                   AS '最高分',
    MIN(sc.score)                                                                   AS '最低分',
    AVG(sc.score)                                                                   AS '平均分',
    SUM(IF(sc.score >= 60, 1, 0)) * 100.0 / COUNT(sc.student_id)                    AS '及格率',
    SUM(IF(sc.score >= 70 AND sc.score <= 80, 1, 0)) * 100.0 / COUNT(sc.student_id) AS '中等率',
    SUM(IF(sc.score >= 80 AND sc.score <= 90, 1, 0)) * 100.0 / COUNT(sc.student_id) AS '优良率',
    SUM(IF(sc.score >= 90, 1, 0)) * 100.0 / COUNT(sc.student_id)                    AS '优秀率',
    COUNT(sc.student_id)                                                            AS '选修人数'
FROM course c
JOIN score sc ON c.course_id = sc.course_id
GROUP BY c.course_id, c.course_name
ORDER BY '选修人数' DESC, c.course_id ASC;


# 17. 查询男生和女生的人数。
SELECT gender, COUNT(*) AS gender_count
FROM student
GROUP BY gender;


# 18. 查询年龄最大的学生姓名。
SELECT name
FROM student
ORDER BY (CURRENT_DATE - birth_date) DESC
LIMIT 1;


# 19. 查询年龄最小的教师姓名。
SELECT name
FROM teacher
ORDER BY (CURRENT_DATE - birth_date)
LIMIT 1;


# 20. 查询学过「张教授」授课的同学的信息。
SELECT s.*
FROM student s
JOIN score sc ON s.student_id = sc.student_id
JOIN course c ON sc.course_id = c.course_id
WHERE c.teacher_id = (
    SELECT teacher_id
    FROM teacher
    WHERE name = '张教授'
);


# 21. 查询查询至少有一门课与学号为"2021001"的同学所学相同的同学的信息 。
SELECT DISTINCT s.*
FROM student s
JOIN score sc ON s.student_id = sc.student_id
WHERE sc.course_id IN (
    SELECT course_id
    FROM score
    WHERE student_id = '2021001'
) AND s.student_id NOT IN ('2021001');


# 22. 查询每门课程的平均分数，并按平均分数降序排列。
SELECT cs_name.course_name, AVG(score)
FROM score sc
INNER JOIN (
    SELECT course_id, course_name
    FROM course
) AS cs_name ON sc.course_id = cs_name.course_id
GROUP BY sc.course_id
ORDER BY AVG(score) DESC;


# 23. 查询学号为"2021001"的学生所有课程的分数。
SELECT sc.course_id, course_name, score
FROM score sc
JOIN course on sc.course_id = course.course_id
WHERE student_id = 2021001;


# 24. 查询所有学生的姓名、选修的课程名称和分数
SELECT name, course_name, score
FROM course c,student s,score sc
WHERE sc.course_id = c.course_id AND sc.student_id = s.student_id;


# 25. 查询每个教师所教授课程的平均分数。
SELECT
    t.teacher_id,
    t.name AS '教师名',
    c.course_id,
    c.course_name AS '课程名',
    AVG(sc.score) AS '平均分数'
FROM
    teacher t
JOIN
    course c ON t.teacher_id = c.teacher_id
JOIN
    score sc ON c.course_id = sc.course_id
GROUP BY
    c.course_id;


# 26. 查询分数在80到90之间的学生姓名和课程名称。
SELECT name, course_name
FROM score
JOIN student ON score.student_id = student.student_id
Join course c on score.course_id = c.course_id
WHERE score >= 80 AND score <90;


# 27. 查询每个班级的平均分数。
SELECT my_class, AVG(score)
FROM score
JOIN student ON score.student_id = student.student_id
GROUP BY my_class;


# 28. 查询没学过"王讲师"老师讲授的任一门课程的学生姓名
SELECT s.name
FROM student s
WHERE NOT EXISTS (
    SELECT 1
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    WHERE sc.student_id = s.student_id
    AND c.teacher_id = (
        SELECT teacher_id
        FROM teacher
        WHERE name = '王讲师'
    )
);


# 29. 查询两门及其以上小于85分的同学的学号，姓名及其平均成绩。
SELECT
    s.student_id,
    s.name,
    AVG(sc.score) AS '平均成绩'
FROM student s
JOIN score sc ON s.student_id = sc.student_id
WHERE sc.course_id IN (
        SELECT course_id
        FROM score
        WHERE student_id = sc.student_id AND score < 85
    )
GROUP BY
    s.student_id
HAVING
    COUNT(DISTINCT sc.course_id) >= 2;


# 30.查询所有学生的总分并按降序排列。
SELECT name, SUM(score)
FROM score
JOIN student ON score.student_id = student.student_id
GROUP BY score.student_id
ORDER BY SUM(score) DESC;


# 31.查询平均分数超过85分的课程名称。
SELECT course_name, avg_score
FROM course
INNER JOIN (
    SELECT course_id ,AVG(score) AS avg_score
    FROM score
    GROUP BY course_id
    HAVING AVG(score) > 85
) AS 85_course ON 85_course.course_id = course.course_id;


# 32. 查询每个学生的平均成绩排名。---------------------------------------------------!!!!!!!!------------------------------------------------------------
# SELECT s.student_id, name, my_class
# FROM student s
# INNER JOIN (
#     SELECT sc.student_id, AVG(score) AS avg_score
#     FROM score sc
#     GROUP BY student_id
# )AS avg_stu ON s.student_id = avg_stu.student_id;


# 33. 查询每门课程分数最高的学生姓名和分数。
SELECT
    s.name,
    sc.course_id,
    sc.score
FROM score sc
JOIN student s ON sc.student_id = s.student_id
WHERE sc.score = (
        SELECT MAX(sc2.score)
        FROM score sc2
        WHERE sc2.course_id = sc.course_id
        )
ORDER BY course_id;


# 34. 查询选修了"高等数学"和"大学物理"的学生姓名。
# 使用子查询：
SELECT s.name
FROM student s
WHERE s.student_id IN (
    SELECT sc.student_id
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    WHERE c.course_name = '高等数学'
)
AND s.student_id IN (
    SELECT sc.student_id
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    WHERE c.course_name = '大学物理'
);
# 使用EXISTS：
SELECT s.name
FROM student s
WHERE EXISTS (
    SELECT 1
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    WHERE sc.student_id = s.student_id AND c.course_name = '高等数学'
)
AND EXISTS (
    SELECT 1
    FROM score sc
    JOIN course c ON sc.course_id = c.course_id
    WHERE sc.student_id = s.student_id AND c.course_name = '大学物理'
);


# 35. 按平均成绩从高到低显示所有学生的所有课程的成绩以及平均成绩（没有选课则为空）。-------------------------------------------!!!!!!-------------------------------------------------


# 36. 查询分数最高和最低的学生姓名及其分数。
SELECT
    s.name AS student_name,
    sc.score AS score
FROM student s
JOIN score sc ON s.student_id = sc.student_id
WHERE sc.score = (
        SELECT MAX(score) FROM score
    )OR sc.score = (
        SELECT MIN(score) FROM score
    );


# 37. 查询每个班级的最高分和最低分。
SELECT
    s.my_class,
    MAX(sc.score) AS highest_score,
    MIN(sc.score) AS lowest_score
FROM score sc
JOIN student s ON sc.student_id = s.student_id
GROUP BY s.my_class;


# 38. 查询每门课程的优秀率（优秀为90分）。
SELECT
    c.course_id,
    c.course_name,
    SUM(IF(sc.score >= 90, 1, 0))                                          AS '优秀人数',
    COUNT(sc.student_id)                                                   AS '选修人数',
    ROUND(SUM(IF(sc.score >= 90, 1, 0)) * 100.0 / COUNT(sc.student_id), 2) AS '优秀率'
FROM course c
JOIN score sc ON c.course_id = sc.course_id
GROUP BY c.course_id, c.course_name;


# 39. 查询平均分数超过班级平均分数的学生。-----------------------------!!!!!!---------------------------------
# SELECT
#     student.student_id,
#     name,
#     AVG(score) AS average_score
# FROM
#     school.student
# JOIN
#     score ON school.student.student_id = score.student_id
# GROUP BY
#     student_id, name
# HAVING
#     AVG(score) > (
#         SELECT AVG(score)
#         FROM score
#         JOIN student ON score.student_id = student.student_id
#         WHERE student.my_class = school.student.my_class
#     );


#40. 查询每个学生的分数及其与课程平均分的差值。
WITH cte_avg AS (
    SELECT AVG(score) AS avg_c,course_id
    FROM score
    GROUP BY course_id
)
SELECT name,sc.course_id, (sc.score - cte_avg.avg_c)
FROM score sc
JOIN student s ON sc.student_id = s.student_id
JOIN cte_avg ON cte_avg.course_id = sc.course_id;


#42. 查询所有课程分数都高于85分的学生姓名。
SELECT s.name
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id
HAVING MIN(sc.score) > 85;


# 43. 查询平均成绩大于等于90分的同学的学生编号和学生姓名和平均成绩。
SELECT
    s.student_id,
    name,
    AVG(score) AS '平均成绩'
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY sc.student_id
HAVING AVG(score) >= 90;


# 44. 查询选修课程数量最少的学生姓名。
SELECT s.name,COUNT(sc.course_id) AS course_count
FROM student s
JOIN score sc ON s.student_id = sc.student_id
GROUP BY s.student_id, s.name
HAVING course_count = (
        SELECT MIN(courses_count)
        FROM (
            SELECT COUNT(sc2.course_id) AS courses_count
            FROM score sc2
            GROUP BY sc2.student_id
        ) AS subquery
    );


# 50. 查询每个班级的学生人数和平均年龄。
SELECT
    my_class AS '班级',
    COUNT(*) AS '学生人数',
    AVG(TIMESTAMPDIFF(YEAR, birth_date, CURDATE())) AS '平均年龄'
FROM student
GROUP BY my_class;