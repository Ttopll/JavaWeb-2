package com.jw22;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

@WebServlet(name = "TestServlet", urlPatterns = "/servlet")
public class ListenerServlet extends HttpServlet {

    // 处理GET请求的方法
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 模拟一些处理，例如数据库查询或文件处理
        try {
            // 模拟处理时间，这里暂停1秒
            Thread.sleep(1000); // 模拟处理时间
        } catch (InterruptedException e) {
            // 如果线程被中断，打印异常堆栈信息
            e.printStackTrace();
        }
        // 向客户端发送响应
        resp.getWriter().write("Test Servlet Response");
    }

    // 处理POST请求的方法，这里直接调用doGet方法，以简化示例
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}