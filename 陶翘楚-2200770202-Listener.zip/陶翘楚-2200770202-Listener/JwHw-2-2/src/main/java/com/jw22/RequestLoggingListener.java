package com.jw22;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;

import java.util.Date;
import java.util.logging.Logger;

// 使用@WebListener注解标记这个类为一个监听器
@WebListener
public class RequestLoggingListener implements ServletRequestListener {

    // 创建一个Logger实例用于记录日志
    private static final Logger logger = Logger.getLogger(RequestLoggingListener.class.getName());

    // 当请求初始化时调用此方法
    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        // 将ServletRequestEvent转换为HttpServletRequest
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        // 记录请求开始的时间戳
        long startTime = System.currentTimeMillis();
        // 将开始时间保存到请求属性中，以便在请求结束时使用
        request.setAttribute("startTime", startTime);
    }

    // 当请求销毁时调用此方法
    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        // 将ServletRequestEvent转换为HttpServletRequest
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();
        // 从请求属性中获取开始时间
        long startTime = (Long) request.getAttribute("startTime");
        // 获取当前时间戳
        long endTime = System.currentTimeMillis();
        // 计算请求处理的总时间
        long processingTime = endTime - startTime;

        // 获取客户端IP地址
        String clientIp = request.getRemoteAddr();
        // 获取请求方法
        String requestMethod = request.getMethod();
        // 获取请求URI
        String requestUri = request.getRequestURI();
        // 获取查询字符串
        String queryString = request.getQueryString();
        // 获取User-Agent
        String userAgent = request.getHeader("User-Agent");

        // 记录和验证信息

        System.out.println("Request Time: " + startTime );
        System.out.println("Client IP: " + clientIp);
        System.out.println("Request Method: " + requestMethod);
        System.out.println("Request URI: " + requestUri);
        System.out.println("Query String: " + queryString);
        System.out.println("User-Agent: " + userAgent);
        System.out.println("Processing Time: " + processingTime);

        // 使用Logger记录请求的详细信息
        logger.info(String.format("Request Time: %s, Client IP: %s, Method: %s, URI: %s, Query String: %s, User-Agent: %s, Processing Time: %d ms",
                new java.util.Date(), clientIp, requestMethod, requestUri, queryString, userAgent, processingTime));

    }
}