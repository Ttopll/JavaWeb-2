# RequestLoggingListener 和 ListenerServlet 文档

## RequestLoggingListener 监听器

#### 功能

RequestLoggingListener 监听器实现了 ServletRequestListener 接口，用于在请求初始化和销毁时记录日志。它记录了请求的开始时间、结束时间、处理时间、客户端IP、请求方法、请求URI、查询字符串和User-Agent。

#### 实现细节

- requestInitialized 方法：在请求初始化时被调用。它将当前时间戳保存到请求属性中，以便在请求结束时使用。
- requestDestroyed 方法：在请求销毁时被调用。它从请求属性中获取开始时间，计算请求处理的总时间，并记录请求的详细信息到控制台和日志中。

#### 额外功能

- 使用 Logger 类记录日志，便于在生产环境中跟踪和监控请求。
- 打印请求的详细信息到控制台，便于开发和调试。

# ListenerServlet Servlet

#### 功能

ListenerServlet 是一个简单的 Servlet，用于模拟请求处理。它处理 GET 和 POST 请求，并在处理请求时模拟一些处理时间。

#### 实现细节

- doGet 方法：处理 GET 请求。它模拟数据库查询或文件处理，通过 Thread.sleep(1000) 暂停1秒来模拟处理时间。
- doPost 方法：处理 POST 请求。为了简化示例，它直接调用 doGet 方法。

#### 额外功能

- 通过 Thread.sleep 模拟请求处理时间，以便在 RequestLoggingListener 中记录处理时间。
- 响应客户端请求，发送简单的文本消息 "Test Servlet Response"。

***

### 使用说明

1. 将 RequestLoggingListener 和 ListenerServlet 部署到支持 Servlet 4.0 或更高版本的 Web 容器中。
2. 通过浏览器或其他 HTTP 客户端向 ListenerServlet 发送请求。
3. 观察控制台和日志输出，以查看请求的详细信息和处理时间

### 注意事项

确保 Web 容器支持 Servlet 4.0 或更高版本，以便正确使用 jakarta.servlet 包。